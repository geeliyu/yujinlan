<?php get_header(); ?>

<div class="content">

	<?php get_template_part('inc/page-title'); ?>
	
	<div class="content-inner group">
	
	</div>
	
</div><!--/.content-->

<div id="move-sidebar-content"></div>

<?php get_footer(); ?>